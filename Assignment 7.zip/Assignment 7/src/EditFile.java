import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class EditFile {

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);

        //gets the source file name from the user
        System.out.print("Enter the file name: ");
        String sourceFile = scnr.nextLine();

        // creates a new file object
        File file = new File(sourceFile);

        //checks if the file the user entered exists
        if (!file.exists()) {
            System.out.println("File does not exist.");
            return;
        }

        //creates new temporary file
        String tempFileName = "Temp1";
        int i = 1;
        File tempFile = new File(tempFileName + i);

        //changes the name of the temporary file if a new one is created
        while (tempFile.exists()) {
            i++;
            tempFile = new File(tempFileName + i);
        }


        try (Scanner fileInput = new Scanner(new FileReader(file))) {
            try (FileWriter tempFileWriter = new FileWriter(tempFile)) {
                // copies the text from the source file to the temporary file and performs the required task
                while (fileInput.hasNextLine()) {
                    String line = fileInput.nextLine();
                    String[] sentences = line.split("\\.");
                    for (String sentence : sentences) {
                        tempFileWriter.write(sentence.trim() + "\n");
                    }
                }
            }
            catch (IOException e) {
                System.out.println("Error writing to temp file.");
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("Error reading file.");
        }

        // copies the new lines from the temporary file back to the source file
        try (Scanner tempFileInput = new Scanner(new FileReader(tempFile))) {
            try (FileWriter fileWriter = new FileWriter(file)) {
                while (tempFileInput.hasNextLine()) {
                    fileWriter.write(tempFileInput.nextLine() + "\n");
                }
            }
            catch (IOException e) {
                System.out.println("Error writing to file.");
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("Error reading temp file.");
        }

        if (!tempFile.delete()) {
            System.out.println("Error deleting temp file.");
        }
    }
}
