import java.util.Random;

public class Hangman {
    //secretWord to hold the secret word
    private String secretWord;
    //userGuess variable
    private String userGuess = "";
    /**
     * Constructor to choose a random secret word
     * and fill blanks in the userGuess word
     *
     */
    public Hangman() {
        //declare a list of random words
        String[] list = {"hangman", "president", "building", "alphabets", "organization"};
        //declare a random object to get a random number
        Random rand = new Random();
        //get a random integer in range[0-5]
        int index = Math.abs(rand.nextInt(6));
        //choose the word using the index
        this.secretWord = list[index];
        int length = this.secretWord.length();
        //initialize user guess with underscores
        for (int i = 0; i < length; i++) {
            this.userGuess = this.userGuess + "_";
        }
    }
/**
 * getter method of the secret word
 *
 * @return String:secretWord returns the randomly generated string for secret word
 */
public String getSecretWord()
{
    return secretWord;
}
    /**
     * Setter method of secret word
     *
     * @param secretWord
     */
    public void setSecretWord(String secretWord)
    {
        this.secretWord = secretWord;
    }
    /**
     * getter method of the user guess word
     *
     * @return String: returns the user's guess
     */
    public String getUserGuess()
    {
        return this.userGuess;
    }
    /**
     * setter method of the user guess
     *
     * @param guess holds the value of the user's guess
     */
    public void setUserGuess(String guess)
    {
        this.userGuess = guess;
    }
    /**
     * toString returns the user guess and the secret word
     *
     * @return returns a string with the usergues and the secret word
     */
    public String toString()
    {
        return "Secret Word: " + this.secretWord + "\n" + "User Guess: " + this.userGuess;
    }
}







