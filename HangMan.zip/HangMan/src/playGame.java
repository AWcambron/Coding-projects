import java.util.Scanner;
/**
 * @author 6348507
 *
 * Title: IntelliJ Programming Challenge #5 - Hangman
 *
 * Semester: COP2210 - Fall 2022
 * Professor's Name: Prof. Charters
 * Description of Program’s Functionality:
 * The project requires coding of 2 classes:
 * 1. a domain class called Hangman
 * 2. a driver class called PlayGame
 * This program demonstrates to create a simulation of the Hangman game.
 *
 */


public class playGame {
    //global static variable for games won and games lost
    public static int gamesWon = 0;
    public static int gamesLost = 0;

    /**
     * this is the main method used to create an object
     * of Hangman type and allows the user to play game until he/she chooses
     * to exit
     *
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("WELCOME TO THE HANGMAN GAME");
        //scanner object to take input
        Scanner input = new Scanner(System.in);
        boolean playAgain = true;
        do {
            //create an object of the Hangman class
            Hangman aGame = new Hangman();
            //call the method processGuesses() to play the game
            processGuesses(aGame);
            //call the method determineWinner() to find if uer won or not
            determineWinner(aGame);
            //ask the user if they want to continue or not
            System.out.print("Play Again? (Yes or No): ");
            //if choice is yes set playAgain to true else set it to false
            String choice = input.next();
            if (choice.compareToIgnoreCase("Yes") == 0) {
                playAgain = true;
            } else {
                playAgain = false;
            }
        } while (playAgain);
        //call summarize() to show the overall results
        summarize();
    }

    /**
     * This method allows the user to guess the secret word
     *
     * @param aGame holds an object of the hangman class
     */
    private static void processGuesses(Hangman aGame) {
        Scanner input = new Scanner(System.in);
        //find the length of the secret word
        int secretWordLength = aGame.getSecretWord().length();
        //total chances is 3 times the length of secret word
        int chances = 3 * secretWordLength;
        int usedChances = 0;
        //iterate until user guesses the word or chances are completed
        while (usedChances < chances &&
                !(aGame.getSecretWord().equalsIgnoreCase(aGame.getUserGuess()))) {
            usedChances++;
            //prompt the user for a char
            System.out.print("Guess a letter: ");
            char ch = input.next().charAt(0);
            //convert the char to lower case
            ch = Character.toLowerCase(ch);
            int loc = -1;
            //iterate until ch is present in the secret word
            do {
                //find the next position of the ch
                loc = aGame.getSecretWord().indexOf(ch, loc + 1);
                //if the position is valid
                if (loc != -1) {
                    //take the userGuess
                    String userGuess = aGame.getUserGuess();
                    //replace the _ at position with the ch as steps mentioned in question
                    userGuess = userGuess.substring(0, loc) + ch + userGuess.substring(loc + 1);
                    System.out.println("User Guess: " + userGuess);
                    //set the userGuess using the setter method
                    aGame.setUserGuess(userGuess);
                }
            } while (loc != -1);
        }
    }

    /**
     * This method determines the winner
     * and based upon win or loss increase the counter gamesWon or gamesLost
     *
     * @param aGame is an object of the hangman class that will be used to call methods from the class
     */
    private static void determineWinner(Hangman aGame) {
        //if the secret word is same as user guess
        //increase gamesWon by 1 else increase gamesLost by 1
        if (aGame.getSecretWord().compareToIgnoreCase(aGame.getUserGuess()) == 0) {
            gamesWon++;
        } else {
            gamesLost++;
        }
    }

    /**
     * This method prints the overall result after all the rounds are completed
     */
    public static void summarize() {
        System.out.println("Total number of correct guess: " + gamesWon);
        System.out.println("Total number of incorrect guess: " + gamesLost);
    }
}
